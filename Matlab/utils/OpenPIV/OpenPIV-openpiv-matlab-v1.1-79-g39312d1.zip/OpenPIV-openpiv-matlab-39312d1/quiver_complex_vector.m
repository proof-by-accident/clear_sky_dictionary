function quiver_complex_vector(vector,varargin)
% compelements openpiv-matlab
% for shortcut of quiver

quiver(real(vector),imag(vector),varargin{:});